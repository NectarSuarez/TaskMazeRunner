The two main classes to run are:

* algernon.subsumption.demo.Demo
* algernon.mazesolver.subsumption.WallFollower
	
To run this, you will need to install Simbad:

	http://simbad.sourceforge.net/index.php
https://www.youtube.com/watch?v=3Lipz8ifKSc